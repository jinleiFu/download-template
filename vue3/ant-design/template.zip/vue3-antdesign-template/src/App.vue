<template>
  <div id="vue3-template">
    <a-config-provider
      :locale="locale"
      :autoInsertSpaceInButton="false"
      :transformCellText="({ text }) => text || '-'"
    >
      <router-view />
    </a-config-provider>
  </div>
</template>
<script>
  import zhCN from 'ant-design-vue/es/locale/zh_CN'
  export default {
    name: 'App',
    data() {
      return {
        locale: zhCN,
      }
    },
  }
</script>
<style lang="less">
  #vue3-template {
    background-color: #fff;
  }
</style>
