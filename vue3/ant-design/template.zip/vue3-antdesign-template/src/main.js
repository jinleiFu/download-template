import { createApp } from 'vue'
import Antd from 'ant-design-vue'
import App from './App'
import router from './router'
import store from './store'
import directives from '@/directives/index.js'
import './router/permissions'
import 'ant-design-vue/dist/antd.less'
import '@/styles/index.less'

createApp(App).use(store).use(router).use(Antd).use(directives).mount('#app')
