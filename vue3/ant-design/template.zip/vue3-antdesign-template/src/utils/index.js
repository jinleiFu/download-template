/**
 * @description 格式化时间
 * @param time
 * @param cFormat
 * @returns {string|null}
 */
export function parseTime(time, cFormat) {
  if (arguments.length === 0) {
    return null
  }
  const format = cFormat || '{y}-{m}-{d} {h}:{i}:{s}'
  let date
  if (typeof time === 'object') {
    date = time
  } else {
    if (typeof time === 'string' && /^[0-9]+$/.test(time)) {
      time = parseInt(time)
    }
    if (typeof time === 'number' && time.toString().length === 10) {
      time = time * 1000
    }
    date = new Date(time)
  }
  const formatObj = {
    y: date.getFullYear(),
    m: date.getMonth() + 1,
    d: date.getDate(),
    h: date.getHours(),
    i: date.getMinutes(),
    s: date.getSeconds(),
    a: date.getDay(),
  }
  return format.replace(/{([ymdhisa])+}/g, (result, key) => {
    let value = formatObj[key]
    if (key === 'a') {
      return ['日', '一', '二', '三', '四', '五', '六'][value]
    }
    if (result.length > 0 && value < 10) {
      value = '0' + value
    }
    return value || 0
  })
}

/**
 * @description 格式化时间
 * @param time
 * @param option
 * @returns {string}
 */
export function formatTime(time, option) {
  if (('' + time).length === 10) {
    time = parseInt(time) * 1000
  } else {
    time = +time
  }
  const d = new Date(time)
  const now = Date.now()

  const diff = (now - d) / 1000

  if (diff < 30) {
    return '刚刚'
  } else if (diff < 3600) {
    // less 1 hour
    return Math.ceil(diff / 60) + '分钟前'
  } else if (diff < 3600 * 24) {
    return Math.ceil(diff / 3600) + '小时前'
  } else if (diff < 3600 * 24 * 2) {
    return '1天前'
  }
  if (option) {
    return parseTime(time, option)
  } else {
    const realMonth = d.getMonth() + 1
    return `${realMonth}月${d.getDate()}日${d.getHours()}时${d.getMinutes()}分`
  }
}

/**
 * @description 将url请求参数转为json格式
 * @param url
 * @returns {{}|any}
 */
export function paramObj(url) {
  const search = url.split('?')[1]
  if (!search) {
    return {}
  }
  return JSON.parse(
    '{"' +
      decodeURIComponent(search)
        .replace(/"/g, '\\"')
        .replace(/&/g, '","')
        .replace(/=/g, '":"')
        .replace(/\+/g, ' ') +
      '"}'
  )
}

/**
 * @description 父子关系的数组转换成树形结构数据
 * @param data
 * @returns {*}
 */
export function translateDataToTree(data) {
  const parent = data.filter(
    (value) => value.parentId === 'undefined' || value.parentId == null
  )
  const children = data.filter(
    (value) => value.parentId !== 'undefined' && value.parentId != null
  )
  const translator = (parent, children) => {
    parent.forEach((parent) => {
      children.forEach((current, index) => {
        if (current.parentId === parent.id) {
          const temp = JSON.parse(JSON.stringify(children))
          temp.splice(index, 1)
          translator([current], temp)
          typeof parent.children !== 'undefined'
            ? parent.children.push(current)
            : (parent.children = [current])
        }
      })
    })
  }
  translator(parent, children)
  return parent
}

/**
 * @description 树形结构数据转换成父子关系的数组
 * @param data
 * @returns {[]}
 */
export function translateTreeToData(data) {
  const result = []
  data.forEach((item) => {
    const loop = (data) => {
      result.push({
        id: data.id,
        name: data.name,
        parentId: data.parentId,
      })
      const child = data.children
      if (child) {
        for (let i = 0; i < child.length; i++) {
          loop(child[i])
        }
      }
    }
    loop(item)
  })
  return result
}

/**
 * @description 10位时间戳转换
 * @param time
 * @returns {string}
 */
export function tenBitTimestamp(time) {
  const date = new Date(time * 1000)
  const y = date.getFullYear()
  let m = date.getMonth() + 1
  m = m < 10 ? '' + m : m
  let d = date.getDate()
  d = d < 10 ? '' + d : d
  let h = date.getHours()
  h = h < 10 ? '0' + h : h
  let minute = date.getMinutes()
  let second = date.getSeconds()
  minute = minute < 10 ? '0' + minute : minute
  second = second < 10 ? '0' + second : second
  return y + '年' + m + '月' + d + '日 ' + h + ':' + minute + ':' + second
}

/**
 * @description 13位时间戳转换
 * @param time
 * @returns {string}
 */
export function thirteenBitTimestamp(time) {
  const date = new Date(time / 1)
  const y = date.getFullYear()
  let m = date.getMonth() + 1
  m = m < 10 ? '' + m : m
  let d = date.getDate()
  d = d < 10 ? '' + d : d
  let h = date.getHours()
  h = h < 10 ? '0' + h : h
  let minute = date.getMinutes()
  let second = date.getSeconds()
  minute = minute < 10 ? '0' + minute : minute
  second = second < 10 ? '0' + second : second
  return y + '年' + m + '月' + d + '日 ' + h + ':' + minute + ':' + second
}

/**
 * @description 获取随机id
 * @param length
 * @returns {string}
 */
export function uuid(length = 32) {
  const num = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890'
  let str = ''
  for (let i = 0; i < length; i++) {
    str += num.charAt(Math.floor(Math.random() * num.length))
  }
  return str
}

/**
 * @description m到n的随机数
 * @param m
 * @param n
 * @returns {number}
 */
export function random(m, n) {
  return Math.floor(Math.random() * (m - n) + n)
}

/**
 * @description addEventListener
 * @type {function(...[*]=)}
 */
export const on = (function () {
  return function (element, event, handler, useCapture = false) {
    if (element && event && handler) {
      element.addEventListener(event, handler, useCapture)
    }
  }
})()

/**
 * @description removeEventListener
 * @type {function(...[*]=)}
 */
export const off = (function () {
  return function (element, event, handler, useCapture = false) {
    if (element && event) {
      element.removeEventListener(event, handler, useCapture)
    }
  }
})()

// 根据citycode查找对应的省市区数据code
export const getCityCodeAll = (function () {
  return function (arr, arrs, val) {
    if (val === 'code') {
      arr.forEach((item) => {
        arrs.push(item.cityCode)
        if (item.children && item.children.length) {
          getCityCodeAll(item.children, arrs, 'code')
        }
      })
    }
    if (val === 'name') {
      arr.forEach((item) => {
        arrs.push(item.cityName)
        if (item.children && item.children.length) {
          getCityCodeAll(item.children, arrs, 'name')
        }
      })
    }
  }
})()

/**
 * @param arr:遍历的数组
 * @param pushKeyName:push进入新数组的key名
 * @param itemArrKeyName:需要遍历的子数组的key名
 */
// export const getNewArray = (function () {
//   const newArr = []
//   return function (arr, pushKeyName, itemArrKeyName) {
//     arr.forEach((item) => {
//       newArr.push(item[pushKeyName])
//       if (item[itemArrKeyName] && item[itemArrKeyName].length) {
//         getNewArray(item[itemArrKeyName], pushKeyName, itemArrKeyName)
//       }
//     })
//     return newArr
//   }
// })()

// let a = [
//   {
//     cityCode: 110000,
//     cityName: '北京市',
//     childrens: [
//       {
//         cityCode: 110100,
//         cityName: '市辖区',
//         childrens: [
//           {
//             cityCode: 110101,
//             cityName: '东城区',
//           },
//         ],
//       },
//     ],
//   },
// ]
// let b = []
// b = getNewArray(a, 'cityCode', 'childrens')
// console.log(111, b)

// 校验图片大小

/**
 * @param fileList:需要校验的图片数组
 * @param size:图片大小限制
 */
export function checkImageSize(fileList, size) {
  return new Promise((resolve, reject) => {
    if (fileList && fileList.length > 0) {
      for (let item = 0; item < fileList.length; item++) {
        if (fileList[item].size > size * 1024 * 1024) {
          fileList[item].status = 'error'
          reject(fileList[item])
          return
        }
      }
      resolve()
    } else {
      resolve()
    }
  })
}

/**
 * 添加单位
 * @param {String | Number} value 单位值 字符串单位/数值
 */
export function addUnit(value) {
  const REGEXP = /^-?\d+(\.\d+)?$/
  return REGEXP.test('' + value) ? value + 'px' : value
}

/**
 * 数据类型判断
 * @param {Any} value
 */
export function judgeType(value) {
  return Object.prototype.toString.call(value).slice(8, -1).toLowerCase()
}

/**
 * 移除数组中没有数据的项
 * @param {Array} list 数组项
 * return 有数据的数组
 */
export function removeEmptyItem(list) {
  const copyList = JSON.parse(JSON.stringify(list))
  return copyList.filter((item) =>
    Object.keys(item).some((key) => (item[key] ? item[key]['code'] : item[key]))
  )
}
