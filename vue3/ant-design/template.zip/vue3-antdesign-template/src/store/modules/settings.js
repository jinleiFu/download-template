import defaultSettings from '@/config'

const { title, i18n } = defaultSettings

const state = () => ({
  title,
  device: 'desktop',
  language: i18n,
})
const getters = {
  device: (state) => state.device,
  language: (state) => state.language,
  title: (state) => state.title,
}
const mutations = {
  toggleDevice(state, device) {
    state.device = device
  },
  changeLanguage(state, language) {
    localStorage.setItem('vehicle-web-language', `{"language":"${language}"}`)
    state.language = language
  },
}
const actions = {
  toggleDevice({ commit }, device) {
    commit('toggleDevice', device)
  },
  changeLanguage: ({ commit }, language) => {
    commit('changeLanguage', language)
  },
}
export default { state, getters, mutations, actions }
