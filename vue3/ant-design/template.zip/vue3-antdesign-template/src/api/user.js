import request from '@/utils/request'

/**
 * 获取用户token
 */
export function userToken(tempToken) {
  return request({
    url: `/user/token/${tempToken}`,
    method: 'GET',
  })
}
