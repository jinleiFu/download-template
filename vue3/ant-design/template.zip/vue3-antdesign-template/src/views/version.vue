<template>
  <div class="version-container">
    <div class="version-content">
      <p class="tips">当前版本号为{{ version }}</p>
    </div>
  </div>
</template>

<script>
  export default {
    setup() {
      return {
        version: process.env.VUE_APP_VERSION,
        environment: process.env.NODE_ENV,
      }
    },
  }
</script>

<style lang="less" scoped>
  .version-container {
    height: 100%;
    position: relative;
    .version-content {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      .tips {
        font-size: 20px;
        font-weight: bold;
        line-height: 24px;
        color: #222;
      }
      .return-home {
        display: block;
        width: 110px;
        height: 36px;
        font-size: 14px;
        line-height: 36px;
        color: #fff;
        text-align: center;
        cursor: pointer;
        background: #1890ff;
        border-radius: 100px;
      }
    }
  }
</style>
