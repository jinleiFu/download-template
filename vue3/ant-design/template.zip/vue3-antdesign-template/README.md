## 技术栈

`vue 3.1.4` 、`vue-router 4.0.10` 、 `vuex 4.0.2` 、 `axios 0.21.1` 、 ` less 4.1.1 ` 、 `ant-design-vue 2.2.2`
、 `webpack 4.41.30`

## 启动步骤

```
# 安装依赖
npm install

# 建议不要直接使用 cnpm 安装依赖，会有各种诡异的 bug。可以通过如下操作解决 npm 下载速度慢的问题
npm install --registry=https://registry.npm.taobao.org

# 启动服务
npm run serve
```

浏览器访问 [http://localhost:8080](http://localhost:8080/)

## 发布

```
# 构建测试环境
npm run build:stage

# 构建生产环境
npm run build:prod
```

## 目录结构

```
├── README.md
├── babel.config.js                                                 // babel 配置文件
├── package-lock.json                                               // 固化当前安装的每个软件包的版本
├── package.json                                                    // 项目清单
├── prettier.config.js                                              // prettier 配置文件
├── public                                                          // 静态资源
│   └── index.html                                                  // index.html
├── src
│   ├── App.vue                                                     // 主组件
│   ├── api                                                         // 网络请求文件夹
│	│	└── user.js
│	├── assets                                                      // 静态资源
│	│	├── error_images
│	│	│	├── 403.png
│	│	│	├── 404.png
│	│	│	└── cloud.png
│	│	├── login_images
│	│	│	├── login_background.png
│	│	│	└── login_form.png
│	│	└── logo.png
│	├── config                                                      // 网络、webpack配置文件	
│	│	├── config.js
│	│	├── default
│	│	│	├── index.js										
│	│	│	├── network.config.js							
│	│	│	└── setting.config.js					
│	│	└── index.js
│	├── layout                                                      // Layout
│	│	└── index.vue
│	├── main.js                                                     // 入口文件
│	├── router                                                      // 路由配置
│	│	└── index.js
│	├── store                                                       // 全局数据共享
│	│	├── index.js
│	│	└── modules
│	│	    ├── settings.js
│	│	    └── user.js
│	├── styles                                                      // 公用样式
│	│	├── index.less
│	│	└── normalize.less
│	├── utils                                                       // 工具包
│	│	├── accessToken.js
│	│	├── clipboard.js
│	│	├── index.js
│	│	├── pageTitle.js
│	│	├── request.js
│	│	└── validate.js
│	└── views                                                       // 视图
│	    ├── 403.vue                                                 // 403页面
│	    ├── 404.vue                                                 // 404页面
│	    ├── version.vue                                             // 版本查看页面
│	    └── vehicle
│	        └── index.vue
└── vue.config.js                                                   // 可选的配置文件
```
