<template>
  <div class="home">
    <a-alert message="vue3 + ant design模板" type="success" show-icon />
    <a-card class="version-information">
      <template v-slot:title>系统信息</template>
      <div class="ant-table ant-table-bordered">
        <table class="ant-table-tbody" style="text-align: center">
          <tr class="ant-table-row">
            <td>vue</td>
            <td>{{ dependencies['vue'] }}</td>
            <td>ant-design-vue</td>
            <td>{{ dependencies['ant-design-vue'] }}</td>
          </tr>
          <tr class="ant-table-row">
            <td>vuex</td>
            <td>{{ dependencies['vuex'] }}</td>
            <td>vue-router</td>
            <td>{{ dependencies['vue-router'] }}</td>
          </tr>
          <tr class="ant-table-row">
            <td>less</td>
            <td>{{ devDependencies['less'] }}</td>
            <td>axios</td>
            <td>{{ dependencies['axios'] }}</td>
          </tr>
          <tr class="ant-table-row">
            <td>webpack</td>
            <td>4.41.30</td>
            <td>@vue/cli</td>
            <td>{{ devDependencies['@vue/cli-service'] }}</td>
          </tr>
        </table>
      </div>
    </a-card>
  </div>
</template>

<script>
  import { defineComponent } from 'vue'
  import { dependencies, devDependencies } from '*/package.json'

  export default defineComponent({
    setup() {
      return {
        dependencies: dependencies,
        devDependencies: devDependencies,
      }
    },
  })
</script>

<style lang="less" scoped></style>
