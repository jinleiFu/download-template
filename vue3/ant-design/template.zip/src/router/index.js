import { createRouter, createWebHashHistory } from 'vue-router'
import Layout from '@/layout'

export const allRoutes = [
  {
    path: '/',
    component: Layout,
    redirect: '/home',
  },
  {
    path: '/version',
    name: 'Version',
    component: Layout,
    redirect: '/version/index',
    children: [
      {
        path: 'index',
        name: 'VersionIndex',
        component: () => import('@/views/version'),
        meta: {
          title: '版本查看',
        },
      },
    ],
  },
  {
    path: '/home',
    name: 'Home',
    component: Layout,
    redirect: '/home/index',
    children: [
      {
        path: 'index',
        name: 'HomeIndex',
        component: () => import('@/views/home'),
        meta: {
          title: '首页',
        },
      },
    ],
  },
  {
    path: '/401',
    name: '401',
    component: () => import('@/views/401'),
    meta: {
      title: '401',
    },
  },
  {
    path: '/403',
    name: '403',
    component: () => import('@/views/403'),
    meta: {
      title: '403',
    },
  },
  {
    path: '/404',
    name: '404',
    component: () => import('@/views/404'),
    meta: {
      title: '404',
    },
  },
  {
    path: '/:pathMatch(.*)',
    redirect: '/404',
    hidden: true,
  },
]

const router = createRouter({
  history: createWebHashHistory(),
  routes: allRoutes,
})

export default router
