import router from '@/router'
import getPageTitle from '@/utils/pageTitle'

// router.beforeEach(async (to, from, next) => {
//   // console.log(to.path)
//   const hasAccessToken = getAccessToken()
//   const { temp_token: tempToken } = paramObj(location.href)
//   if (routesWhiteList.indexOf(to.path) !== -1) {
//     next()
//   } else if (tempToken) {
//     const hasToken = await store.dispatch('user/getUserToken', tempToken)
//     if (hasToken) {
//       next()
//     } else {
//       removeAccessToken()
//       next({ path: '/403', replace: true })
//     }
//   } else if (hasAccessToken) {
//     const accessRoutes = store.getters['user/routes']
//     if (accessRoutes && accessRoutes.length) {
//       if (accessRoutes.some((menu) => to.path === menu)) {
//         next()
//       } else {
//         next({ path: '/403', replace: true })
//       }
//     } else {
//       const accessRoutesResults = await store.dispatch('user/getMenus')
//       if (accessRoutesResults.some((menu) => to.path === menu)) {
//         next()
//       } else {
//         next({ path: '/403', replace: true })
//       }
//     }
//   } else {
//     next({ path: '/403', replace: true })
//   }
// })
router.afterEach((to) => {
  document.title = getPageTitle(to.meta.title)
})
