<template>
  <div class="layout-wrapper">
    <router-view v-slot="{ Component }">
      <transition mode="out-in" name="fade-transform">
        <component :is="Component" />
      </transition>
    </router-view>
  </div>
</template>
<script>
  import { defineComponent, toRefs, reactive } from 'vue'

  export default defineComponent({
    name: 'Layout',
    setup() {
      const state = reactive({})

      return {
        ...toRefs(state),
      }
    },
  })
</script>
<style lang="less" scoped>
  .layout-wrapper {
    min-width: 1200px;
    height: 100vh;
    padding: 18px 24px;
  }
</style>
