import axios from 'axios'
import {
  contentType,
  requestTimeout,
  successCode,
  tokenName,
  messageDuration,
} from '@/config'
import store from '@/store'
import qs from 'qs'
import router from '@/router'
import { isArray } from '@/utils/validate'
import { message } from 'ant-design-vue'
import { uuid, paramObj } from '@/utils/index'
import { removeAccessToken } from '@/utils/accessToken'
import _ from 'lodash'
// import { h } from 'vue'
// import { CloseOutlined } from '@ant-design/icons-vue'
// loading对象
let loading
// 当前正在请求的数量
let loadingRequestCount = 0

// 将 300ms 间隔内的关闭 loading 便合并为一次。防止连续请求时， loading闪烁的问题
const toHideLoading = _.debounce(() => {
  loading()
  loading = null
}, 300)

// 显示loading
function showLoading() {
  if (loadingRequestCount === 0 && !loading) {
    loading = message.loading('加载中...', 0)
  }
  loadingRequestCount = loadingRequestCount + 1
}

// 隐藏loading
function hideLoading() {
  loadingRequestCount = loadingRequestCount - 1
  loadingRequestCount = Math.max(loadingRequestCount, 0)
  if (loadingRequestCount === 0 && loading) {
    // 关闭loading
    toHideLoading()
  }
}

// 手动关闭的message方法
// const selfMessageError = (content, duration, onClose) => {
//   let _remove
//   let innerText = h('span', { style: { color: '#000000A6' } }, content)
//   let innerIcon = h(CloseOutlined, {
//     style: {
//       marginRight: '0px',
//       marginLeft: '20px',
//       color: '#ccc',
//       cursor: 'pointer',
//     },
//     onclick: () => {
//       _remove()
//     },
//   })
//   let container = h('span', {}, [innerText, innerIcon])

//   _remove = message.error({
//     content: container,
//     duration: duration || 0,
//     onClose: onClose,
//   })
// }

/**
 * @description 处理code异常
 * @param {Number} code 错误码
 * @param {String} msg 错误信息
 * @param {Boolean} hideError 是否隐藏错误信息
 */
const handleCode = (code, msg, hideError) => {
  switch (code) {
    case 401:
      router.push({ path: '/401' }).catch(() => {})
      break
    case 403:
      router.push({ path: '/403' }).catch(() => {})
      break
    default:
      // selfMessageError(msg || `后端接口${code}异常`)
      if (hideError) return
      message.error({
        content: msg || `后端接口${code}异常`,
        duration: messageDuration,
      })
      break
  }
}

/**
 * @description axios初始化
 */
const instance = axios.create({
  baseURL: process.env.VUE_APP_BASE_URL,
  timeout: requestTimeout,
  headers: {
    'Content-Type': contentType,
  },
})

/**
 * @description axios请求拦截器
 */
instance.interceptors.request.use(
  (config) => {
    config.headers['X-Request-ID'] = `${new Date().getTime()}${uuid(3)}`
    // 取消get缓存
    if (/get/i.test(config.method)) {
      config.params = config.params || {}
      config.params.t = Date.parse(new Date())
    }
    if (store.getters['user/accessToken']) {
      config.headers[tokenName] = store.getters['user/accessToken']
    }
    if (
      config.data &&
      config.headers['Content-Type'] ===
        'application/x-www-form-urlencoded;charset=UTF-8'
    ) {
      config.data = qs.stringify(config.data)
    }
    if (config.headers.showLoading !== false) {
      showLoading()
    }
    return config
  },
  (error) => {
    hideLoading()
    return Promise.reject(error)
  }
)

/**
 * @description axios响应拦截器
 */
instance.interceptors.response.use(
  (response) => {
    return new Promise((resolve, reject) => {
      hideLoading()
      const { data, config } = response
      const { businessCode, message } = data
      // console.log('response', response)
      //  操作正常Code数组
      const codeVerificationArray = isArray(successCode)
        ? [...successCode]
        : [...[successCode]]
      //  是否操作正常
      if (codeVerificationArray.includes(businessCode.code)) {
        /**
         * post/delete请求默认添加1s延迟，可通过在headers添加noWait:true去除该行为
         * 可通过在headers添加wait(单位秒)定制化延迟时间
         */
        if (
          !response.config.headers.noWait &&
          (/post/i.test(response.config.method) ||
            /delete/i.test(response.config.method))
        ) {
          setTimeout(() => {
            resolve(data)
          }, response.config.headers.wait || 1000)
        } else {
          resolve(data)
        }
      } else {
        handleCode(businessCode, message, config.headers.hideError)
        reject(
          'vue3模板请求异常拦截:' +
            JSON.stringify({ url: config.url, businessCode, message }) ||
            'Error'
        )
      }
    })
  },
  async (error) => {
    hideLoading()
    const { response, message: msg } = error
    if (error.response && error.response.data) {
      const { status, data } = response
      handleCode(
        status,
        data.businessCode ? data.businessCode.description : '' || msg
      )
      return Promise.reject(error)
    } else {
      let { message: msg } = error
      if (msg === 'Network Error') {
        message.error({
          content: '后端接口连接异常',
          duration: messageDuration,
        })
      } else if (msg.includes('timeout')) {
        message.error({
          content: '后端接口请求超时',
          duration: messageDuration,
        })
      } else if (msg.includes('Request failed with status code')) {
        const code = msg.substr(msg.length - 3)
        if (code === '401') {
          const { temp_token: tempToken } = paramObj(location.href)
          if (tempToken) {
            const hasToken = await store.dispatch(
              'user/getUserToken',
              tempToken
            )
            if (!hasToken) {
              removeAccessToken()
              router.replace({ path: '/403' })
            }
          } else {
            removeAccessToken()
            router.replace({ path: '/401' })
          }
        } else {
          msg = `后端接口${code}异常`
          message.error({
            content: msg,
            duration: messageDuration,
          })
        }
      } else {
        message.error({
          content: '后端接口未知异常',
          duration: messageDuration,
        })
      }
      return Promise.reject(error)
    }
  }
)

export default instance
